import { useState } from "react";
import { LoginPage } from "./components/LoginPage";
import { MainLayout } from "./components/MainLayout";
import { Toaster } from "./components/ui/sonner";

export interface Announcement {
  id: string;
  title: string;
  description: string;
  category: 'academic' | 'events' | 'jobs' | 'general' | 'sports';
  date: string;
  author: string;
  priority: 'high' | 'medium' | 'low';
  department?: string;
}

export interface Course {
  id: string;
  title: string;
  description: string;
  college: string;
  isFree: boolean;
  isOnline: boolean;
  instructor: string;
  date: string;
  time: string;
  location: string;
  registrationLink: string;
}

export interface ClubAnnouncement {
  id: string;
  title: string;
  description: string;
  club: string;
  college: string;
  date: string;
  image?: string;
}

export interface GeneralAnnouncement {
  id: string;
  title: string;
  description: string;
  type:
    | "volunteer"
    | "event"
    | "restaurant"
    | "competition"
    | "hackathon";
  date: string;
  location?: string;
  contact?: string;
}

export interface Settings {
  language: "ar" | "en";
  theme: "light" | "dark";
  emailNotifications: boolean;
  pushNotifications: boolean;
}

export default function App() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [currentUser, setCurrentUser] = useState<string>("");
  const [isManager, setIsManager] = useState(false);
  const [settings, setSettings] = useState<Settings>({
    language: "ar",
    theme: "light",
    emailNotifications: false,
    pushNotifications: false,
  });

  const handleLogin = (universityId: string, password: string) => {
    setCurrentUser(universityId);
    setIsManager(password === 'manager');
    setIsLoggedIn(true);
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setCurrentUser("");
  };

  // Show login page if not logged in
  if (!isLoggedIn) {
    return (
      <>
        <LoginPage onLogin={handleLogin} />
        <Toaster position="top-center" />
      </>
    );
  }

  // Show main app after login
  return (
    <>
      <MainLayout
        currentUser={currentUser}
        onLogout={handleLogout}
        settings={settings}
        onSettingsChange={setSettings}
        isManager={isManager}
      />
      <Toaster position="top-center" />
    </>
  );
}