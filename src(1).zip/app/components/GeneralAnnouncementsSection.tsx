import { Heart, PartyPopper, Coffee, Trophy, Code } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { GeneralAnnouncement } from '../App';

interface GeneralAnnouncementsSectionProps {
  searchQuery: string;
}

const mockGeneralAnnouncements: GeneralAnnouncement[] = [
  {
    id: '1',
    title: 'فرصة تطوعية: المشاركة في تنظيم حفل الجامعة',
    description: 'نبحث عن متطوعين للمساعدة في تنظيم حفل التخرج السنوي. ستحصل على شهادة تطوع معتمدة.',
    type: 'volunteer',
    date: '2025-11-10',
    location: 'مسرح الجامعة الرئيسي',
    contact: 'volunteer@kku.edu.sa'
  },
  {
    id: '2',
    title: 'افتتاح مقهى جديد داخل الحرم الجامعي',
    description: 'يسرنا الإعلان عن افتتاح مقهى "كوفي كورنر" بجانب مكتبة الجامعة. خصم 20% للطلاب!',
    type: 'restaurant',
    date: '2025-11-05',
    location: 'بجانب المكتبة المركزية'
  },
  {
    id: '3',
    title: 'فعالية: يوم الصحة والعافية',
    description: 'كلية الطب تنظم يوماً توعوياً عن الصحة مع فحوصات طبية مجانية واستشارات',
    type: 'event',
    date: '2025-11-14',
    location: 'ساحة كلية الطب'
  },
  {
    id: '4',
    title: 'مسابقة الابتكار الطلابي 2025',
    description: 'قدم مشروعك المبتكر واحصل على فرصة الفوز بجوائز تصل إلى 50,000 ريال',
    type: 'competition',
    date: '2025-11-25',
    contact: 'innovation@kku.edu.sa'
  },
  {
    id: '5',
    title: 'هاكاثون KKU 2025',
    description: 'هاكاثون البرمجة السنوي - 48 ساعة من الابتكار والإبداع. سجل فريقك الآن!',
    type: 'hackathon',
    date: '2025-12-01',
    location: 'مركز الابتكار',
    contact: 'hackathon@kku.edu.sa'
  },
  {
    id: '6',
    title: 'فرصة تطوعية: مبادرة نظافة الحرم الجامعي',
    description: 'انضم لنا في مبادرة تطوعية للحفاظ على نظافة وجمال الحرم الجامعي',
    type: 'volunteer',
    date: '2025-11-08',
    location: 'نقطة التجمع: البوابة الرئيسية'
  }
];

const typeIcons = {
  volunteer: Heart,
  event: PartyPopper,
  restaurant: Coffee,
  competition: Trophy,
  hackathon: Code
};

const typeLabels = {
  volunteer: { label: 'فرصة تطوعية', color: 'bg-pink-100 text-pink-800' },
  event: { label: 'فعالية', color: 'bg-purple-100 text-purple-800' },
  restaurant: { label: 'مطعم/مقهى', color: 'bg-orange-100 text-orange-800' },
  competition: { label: 'مسابقة', color: 'bg-blue-100 text-blue-800' },
  hackathon: { label: 'هاكاثون', color: 'bg-indigo-100 text-indigo-800' }
};

export function GeneralAnnouncementsSection({ searchQuery }: GeneralAnnouncementsSectionProps) {
  const filteredAnnouncements = mockGeneralAnnouncements.filter(announcement => {
    return announcement.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
           announcement.description.toLowerCase().includes(searchQuery.toLowerCase());
  });

  return (
    <div>
      <div className="flex items-center gap-3 mb-6">
        <div className="bg-gradient-to-r from-purple-600 to-pink-600 p-3 rounded-lg">
          <PartyPopper className="w-6 h-6 text-white" />
        </div>
        <div>
          <h2 className="text-gray-900">الإعلانات العامة</h2>
          <p className="text-gray-600 text-sm">فعاليات وفرص ومستجدات الجامعة</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredAnnouncements.map((announcement) => (
          <GeneralAnnouncementCard key={announcement.id} announcement={announcement} />
        ))}
      </div>

      {filteredAnnouncements.length === 0 && (
        <div className="text-center py-12 bg-white/50 rounded-xl">
          <PartyPopper className="w-16 h-16 text-purple-300 mx-auto mb-4" />
          <p className="text-gray-600">لا توجد إعلانات عامة حالياً</p>
        </div>
      )}
    </div>
  );
}

function GeneralAnnouncementCard({ announcement }: { announcement: GeneralAnnouncement }) {
  const Icon = typeIcons[announcement.type];
  const typeInfo = typeLabels[announcement.type];

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('ar-SA', { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };

  return (
    <Card className="hover:shadow-xl transition-all duration-300 hover:-translate-y-1 border-purple-100 bg-white/90 backdrop-blur-sm">
      <CardHeader>
        <div className="flex items-center gap-2 mb-2">
          <Badge className={typeInfo.color}>
            <Icon className="w-3 h-3 ml-1" />
            {typeInfo.label}
          </Badge>
        </div>
        <CardTitle className="text-gray-900 leading-tight">
          {announcement.title}
        </CardTitle>
        <CardDescription className="text-gray-600">
          {announcement.description}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-2 text-sm text-gray-600">
          <div className="flex items-center gap-2">
            <span style={{ color: '#427E5A' }}>📅</span>
            <span>{formatDate(announcement.date)}</span>
          </div>
          {announcement.location && (
            <div className="flex items-center gap-2">
              <span style={{ color: '#427E5A' }}>📍</span>
              <span>{announcement.location}</span>
            </div>
          )}
          {announcement.contact && (
            <div className="flex items-center gap-2">
              <span style={{ color: '#427E5A' }}>✉️</span>
              <span className="text-xs">{announcement.contact}</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
