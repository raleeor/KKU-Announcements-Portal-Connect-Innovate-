import { useState } from 'react';
import { MessageSquarePlus, Send } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Textarea } from './ui/textarea';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Button } from './ui/button';
import { toast } from 'sonner@2.0.3';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';

export function SuggestionsPage() {
  const [suggestionType, setSuggestionType] = useState('general');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!title || !description) {
      toast.error('يرجى ملء جميع الحقول');
      return;
    }

    setIsSubmitting(true);
    
    // Simulate submission
    setTimeout(() => {
      toast.success('تم إرسال اقتراحك بنجاح! شكراً لمساهمتك في تطوير التطبيق');
      setTitle('');
      setDescription('');
      setSuggestionType('general');
      setIsSubmitting(false);
    }, 1000);
  };

  return (
    <main className="container mx-auto px-4 py-6 max-w-4xl">
      <div className="flex items-center gap-3 mb-8">
        <div className="p-3 rounded-lg" style={{ background: 'linear-gradient(to right, #427E5A, #5a9b72)' }}>
          <MessageSquarePlus className="w-6 h-6 text-white" />
        </div>
        <div>
          <h1 className="text-gray-900">الاقتراحات والتحسينات</h1>
          <p className="text-gray-600 text-sm">شاركنا أفكارك لتحسين التطبيق</p>
        </div>
      </div>

      <Card className="bg-white/90 backdrop-blur-sm" style={{ borderColor: '#d4e7dc' }}>
        <CardHeader>
          <CardTitle>إرسال اقتراح</CardTitle>
          <CardDescription>
            نحن نقدر آراءك واقتراحاتك لتطوير تجربة استخدام التطبيق
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="suggestion-type">نوع الاقتراح</Label>
              <Select value={suggestionType} onValueChange={setSuggestionType}>
                <SelectTrigger id="suggestion-type" style={{ borderColor: '#d4e7dc' }}>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="general">اقتراح عام</SelectItem>
                  <SelectItem value="feature">ميزة جديدة</SelectItem>
                  <SelectItem value="improvement">تحسين</SelectItem>
                  <SelectItem value="bug">مشكلة تقنية</SelectItem>
                  <SelectItem value="content">محتوى</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="title">عنوان الاقتراح</Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="مثال: إضافة خاصية التنبيهات الصوتية"
                style={{ borderColor: '#d4e7dc' }}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">تفاصيل الاقتراح</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="اشرح اقتراحك بالتفصيل..."
                rows={6}
                style={{ borderColor: '#d4e7dc' }}
                required
              />
            </div>

            <div className="rounded-lg p-4" style={{ backgroundColor: '#f0f7f3', borderColor: '#d4e7dc', borderWidth: '1px' }}>
              <p className="text-sm" style={{ color: '#2d5a3f' }}>
                💡 سيتم مراجعة جميع الاقتراحات من قبل فريق التطوير وسنعمل على تنفيذ الأفضل منها
              </p>
            </div>

            <Button 
              type="submit" 
              className="w-full gap-2 text-white"
              style={{ background: 'linear-gradient(to right, #427E5A, #5a9b72)' }}
              disabled={isSubmitting}
            >
              {isSubmitting ? (
                <span className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  جاري الإرسال...
                </span>
              ) : (
                <>
                  <Send className="w-4 h-4" />
                  إرسال الاقتراح
                </>
              )}
            </Button>
          </form>
        </CardContent>
      </Card>

      {/* Previous Suggestions */}
      <div className="mt-8">
        <h2 className="text-gray-900 mb-4">اقتراحاتك السابقة</h2>
        <div className="rounded-lg p-8 text-center" style={{ backgroundColor: '#f0f7f3' }}>
          <p className="text-gray-600">لا توجد اقتراحات سابقة</p>
        </div>
      </div>
    </main>
  );
}
