import { Settings as SettingsIcon, Globe, Moon, Mail, Bell } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Label } from './ui/label';
import { Switch } from './ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Settings } from '../App';
import { toast } from 'sonner@2.0.3';
import { useEffect, useState } from 'react';

interface SettingsPageProps {
  settings: Settings;
  onSettingsChange: (settings: Settings) => void;
  onNavigate?: (page: 'home' | 'settings' | 'history' | 'suggestions') => void;
}

export function SettingsPage({ settings, onSettingsChange, onNavigate }: SettingsPageProps) {
  const [showNotificationDemo, setShowNotificationDemo] = useState(false);

  // Show notification when notifications are enabled
  useEffect(() => {
    if (settings.emailNotifications || settings.pushNotifications) {
      if (!showNotificationDemo) {
        setShowNotificationDemo(true);
        
        // Random notification examples
        const notifications = [
          {
            title: '🎓 دورة تدريبية جديدة',
            description: 'دورة "الذكاء الاصطناعي وتطبيقاته" متاحة الآن للتسجيل'
          },
          {
            title: '💻 هاكاثون KKU 2025',
            description: 'سجل فريقك الآن في هاكاثون الجامعة السنوي!'
          },
          {
            title: '🏆 مسابقة الابتكار',
            description: 'آخر موعد لتقديم مشروعك في مسابقة الابتكار'
          }
        ];

        const randomNotification = notifications[Math.floor(Math.random() * notifications.length)];
        
        toast.success(randomNotification.title, {
          description: randomNotification.description,
          duration: 5000,
        });
      }
    } else {
      setShowNotificationDemo(false);
    }
  }, [settings.emailNotifications, settings.pushNotifications]);

  const handleLanguageChange = (language: 'ar' | 'en') => {
    onSettingsChange({ ...settings, language });
    toast.success(language === 'ar' ? 'تم تغيير اللغة إلى العربية' : 'Language changed to English');
  };

  const handleThemeChange = (checked: boolean) => {
    const newTheme = checked ? 'dark' : 'light';
    onSettingsChange({ ...settings, theme: newTheme });
    toast.success(newTheme === 'dark' ? 'تم تفعيل الوضع الليلي' : 'تم تفعيل الوضع النهاري');
  };

  const handleEmailNotificationsChange = (checked: boolean) => {
    onSettingsChange({ ...settings, emailNotifications: checked });
    if (checked) {
      toast.success('تم تفعيل إشعارات البريد الإلكتروني');
    } else {
      toast.info('تم إيقاف إشعارات البريد الإلكتروني');
    }
  };

  const handlePushNotificationsChange = (checked: boolean) => {
    onSettingsChange({ ...settings, pushNotifications: checked });
    if (checked) {
      toast.success('تم تفعيل الإشعارات الفورية');
    } else {
      toast.info('تم إيقاف الإشعارات الفورية');
    }
  };

  return (
    <main className="container mx-auto px-4 py-6 max-w-4xl">
      <div className="flex items-center gap-3 mb-8">
        <div className="p-3 rounded-lg" style={{ background: 'linear-gradient(to right, #427E5A, #5a9b72)' }}>
          <SettingsIcon className="w-6 h-6 text-white" />
        </div>
        <div>
          <h1 className="text-gray-900">الإعدادات</h1>
          <p className="text-gray-600 text-sm">قم بتخصيص تجربتك في النظام</p>
        </div>
      </div>

      <div className="space-y-6">
        {/* Language Settings */}
        <Card className="bg-white/90 backdrop-blur-sm" style={{ borderColor: '#d4e7dc' }}>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Globe className="w-5 h-5" style={{ color: '#427E5A' }} />
              <CardTitle>اللغة</CardTitle>
            </div>
            <CardDescription>
              اختر لغة واجهة النظام
            </CardDescription>
          </CardHeader>
          <CardContent>
            <Select value={settings.language} onValueChange={handleLanguageChange}>
              <SelectTrigger style={{ borderColor: '#d4e7dc' }}>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ar">العربية</SelectItem>
                <SelectItem value="en">English</SelectItem>
              </SelectContent>
            </Select>
          </CardContent>
        </Card>

        {/* Theme Settings */}
        <Card className="bg-white/90 backdrop-blur-sm" style={{ borderColor: '#d4e7dc' }}>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Moon className="w-5 h-5" style={{ color: '#427E5A' }} />
              <CardTitle>المظهر</CardTitle>
            </div>
            <CardDescription>
              التبديل بين الوضع النهاري والليلي
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center justify-between">
              <Label htmlFor="theme-mode" className="text-gray-700">
                الوضع الليلي
              </Label>
              <Switch
                id="theme-mode"
                checked={settings.theme === 'dark'}
                onCheckedChange={handleThemeChange}
              />
            </div>
          </CardContent>
        </Card>

        {/* Notifications Settings */}
        <Card className="bg-white/90 backdrop-blur-sm" style={{ borderColor: '#d4e7dc' }}>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Bell className="w-5 h-5" style={{ color: '#427E5A' }} />
              <CardTitle>الإشعارات</CardTitle>
            </div>
            <CardDescription>
              اختر كيف تريد استقبال الإشعارات
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-gray-500" />
                <Label htmlFor="email-notifications" className="text-gray-700">
                  إشعارات البريد الجامعي
                </Label>
              </div>
              <Switch
                id="email-notifications"
                checked={settings.emailNotifications}
                onCheckedChange={handleEmailNotificationsChange}
              />
            </div>

            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Bell className="w-4 h-4 text-gray-500" />
                <Label htmlFor="push-notifications" className="text-gray-700">
                  الإشعارات الفورية
                </Label>
              </div>
              <Switch
                id="push-notifications"
                checked={settings.pushNotifications}
                onCheckedChange={handlePushNotificationsChange}
              />
            </div>

            <div className="rounded-lg p-4 mt-4" style={{ backgroundColor: '#f0f7f3', borderColor: '#d4e7dc', borderWidth: '1px' }}>
              <p className="text-sm" style={{ color: '#2d5a3f' }}>
                💡 عند تفعيل الإشعارات، ستتلقى تنبيهات عن الدورات والفعاليات والمسابقات الجديدة
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Quick Access Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
          <Card 
            className="bg-white/90 backdrop-blur-sm cursor-pointer hover:shadow-lg transition-shadow"
            style={{ borderColor: '#d4e7dc' }}
            onClick={() => onNavigate && onNavigate('history')}
          >
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-lg" style={{ backgroundColor: '#f0f7f3' }}>
                  <span className="text-2xl">📚</span>
                </div>
                <div>
                  <h3 className="font-medium text-gray-900">سجل الدورات</h3>
                  <p className="text-sm text-gray-600">عرض الدورات المكتملة</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card 
            className="bg-white/90 backdrop-blur-sm cursor-pointer hover:shadow-lg transition-shadow"
            style={{ borderColor: '#d4e7dc' }}
            onClick={() => onNavigate && onNavigate('suggestions')}
          >
            <CardContent className="pt-6">
              <div className="flex items-center gap-3">
                <div className="p-3 rounded-lg" style={{ backgroundColor: '#f0f7f3' }}>
                  <span className="text-2xl">💡</span>
                </div>
                <div>
                  <h3 className="font-medium text-gray-900">الاقتراحات</h3>
                  <p className="text-sm text-gray-600">شاركنا أفكارك</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </main>
  );
}
