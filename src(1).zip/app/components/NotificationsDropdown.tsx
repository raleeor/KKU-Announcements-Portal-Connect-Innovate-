import { Bell } from 'lucide-react';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from './ui/dropdown-menu';
import { ScrollArea } from './ui/scroll-area';

interface Notification {
  id: string;
  title: string;
  description: string;
  type: 'course' | 'event' | 'club' | 'general';
  date: string;
  isNew: boolean;
}

const mockNotifications: Notification[] = [
  {
    id: '1',
    title: 'دورة جديدة: الذكاء الاصطناعي',
    description: 'تم إضافة دورة جديدة عن الذكاء الاصطناعي وتطبيقاته',
    type: 'course',
    date: '2025-10-29T10:00:00',
    isNew: true
  },
  {
    id: '2',
    title: 'هاكاثون KKU 2025',
    description: 'تم الإعلان عن هاكاثون الجامعة السنوي',
    type: 'event',
    date: '2025-10-29T09:30:00',
    isNew: true
  },
  {
    id: '3',
    title: 'نادي البرمجة - مسابقة جديدة',
    description: 'المسابقة السنوية للبرمجة مفتوحة الآن للتسجيل',
    type: 'club',
    date: '2025-10-28T15:20:00',
    isNew: false
  },
  {
    id: '4',
    title: 'افتتاح مقهى جديد',
    description: 'كوفي كورنر افتتح في الحرم الجامعي',
    type: 'general',
    date: '2025-10-28T12:00:00',
    isNew: false
  }
];

export function NotificationsDropdown() {
  const newNotificationsCount = mockNotifications.filter(n => n.isNew).length;

  const formatTime = (dateString: string) => {
    const now = new Date();
    const notifDate = new Date(dateString);
    const diffMs = now.getTime() - notifDate.getTime();
    const diffMins = Math.floor(diffMs / 60000);
    const diffHours = Math.floor(diffMs / 3600000);
    const diffDays = Math.floor(diffMs / 86400000);

    if (diffMins < 60) {
      return `منذ ${diffMins} دقيقة`;
    } else if (diffHours < 24) {
      return `منذ ${diffHours} ساعة`;
    } else if (diffDays === 1) {
      return 'أمس';
    } else {
      return `منذ ${diffDays} يوم`;
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'course':
        return '📚';
      case 'event':
        return '🎉';
      case 'club':
        return '🏅';
      case 'general':
        return '📢';
      default:
        return '📌';
    }
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" className="relative">
          <Bell className="w-6 h-6" />
          {newNotificationsCount > 0 && (
            <Badge 
              className="absolute -top-1 -right-1 px-1.5 py-0 h-5 min-w-5 flex items-center justify-center text-xs"
              style={{ backgroundColor: '#ef4444' }}
            >
              {newNotificationsCount}
            </Badge>
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-80" dir="rtl">
        <DropdownMenuLabel className="text-right">
          الإشعارات
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <ScrollArea className="h-[400px]">
          {mockNotifications.map((notification) => (
            <DropdownMenuItem 
              key={notification.id} 
              className="flex flex-col items-start gap-1 p-3 cursor-pointer"
              style={notification.isNew ? { backgroundColor: '#f0f7f3' } : {}}
            >
              <div className="flex items-start gap-2 w-full">
                <span className="text-xl">{getTypeIcon(notification.type)}</span>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <p className="font-medium text-sm">{notification.title}</p>
                    {notification.isNew && (
                      <Badge 
                        className="text-xs px-1 py-0"
                        style={{ backgroundColor: '#427E5A', color: 'white' }}
                      >
                        جديد
                      </Badge>
                    )}
                  </div>
                  <p className="text-xs text-gray-600 mt-1">
                    {notification.description}
                  </p>
                  <p className="text-xs text-gray-400 mt-1">
                    {formatTime(notification.date)}
                  </p>
                </div>
              </div>
            </DropdownMenuItem>
          ))}
        </ScrollArea>
        <DropdownMenuSeparator />
        <DropdownMenuItem className="text-center justify-center">
          <Button variant="ghost" size="sm" className="w-full" style={{ color: '#427E5A' }}>
            عرض جميع الإشعارات
          </Button>
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
