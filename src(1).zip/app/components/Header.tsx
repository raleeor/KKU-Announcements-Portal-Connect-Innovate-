import { GraduationCap, LogOut, Home, Settings, Edit } from 'lucide-react';
import { Button } from './ui/button';
import { NotificationsDropdown } from './NotificationsDropdown';

interface HeaderProps {
  currentUser: string;
  onLogout: () => void;
  currentPage: 'home' | 'settings' | 'history' | 'suggestions';
  onPageChange: (page: 'home' | 'settings' | 'history' | 'suggestions') => void;
  isManager: boolean;
  onAddAnnouncement?: () => void;
}

export function Header({ currentUser, onLogout, currentPage, onPageChange, isManager, onAddAnnouncement }: HeaderProps) {
  return (
    <header className="text-white shadow-md sticky top-0 z-50" style={{ background: 'linear-gradient(to right, #427E5A, #5a9b72)' }}>
      <div className="container mx-auto px-4 py-2">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="bg-white/20 p-1.5 rounded-lg backdrop-blur-sm">
              <GraduationCap className="w-5 h-5" />
            </div>
            <div className="hidden sm:block">
              <h1 className="text-white text-sm">جامعة الملك خالد - KKU</h1>
              <p className="text-xs" style={{ color: '#e8f4ed' }}>نظام الإعلانات الإلكترونية</p>
            </div>
          </div>
          
          <div className="flex items-center gap-1">
            <Button
              onClick={() => onPageChange('home')}
              variant="ghost"
              size="sm"
              className={`text-white hover:bg-white/10 gap-1 px-2 py-1 h-8 ${currentPage === 'home' ? 'bg-white/20' : ''}`}
            >
              <Home className="w-3.5 h-3.5" />
              <span className="hidden md:inline text-xs">الرئيسية</span>
            </Button>
            
            <Button
              onClick={() => onPageChange('settings')}
              variant="ghost"
              size="sm"
              className={`text-white hover:bg-white/10 gap-1 px-2 py-1 h-8 ${currentPage === 'settings' ? 'bg-white/20' : ''}`}
            >
              <Settings className="w-3.5 h-3.5" />
              <span className="hidden md:inline text-xs">الإعدادات</span>
            </Button>
            
            {isManager && onAddAnnouncement && (
              <Button
                onClick={onAddAnnouncement}
                variant="ghost"
                size="sm"
                className="text-white hover:bg-white/10 gap-1 bg-white/10 px-2 py-1 h-8"
              >
                <Edit className="w-3.5 h-3.5" />
                <span className="hidden md:inline text-xs">إضافة</span>
              </Button>
            )}
            
            <div className="hidden lg:flex items-center gap-1.5 bg-white/10 px-2 py-1 rounded-md backdrop-blur-sm">
              <div className="text-right">
                <p className="text-xs text-white">{currentUser}</p>
              </div>
            </div>
            
            <NotificationsDropdown />
            
            <Button
              onClick={onLogout}
              variant="ghost"
              size="sm"
              className="text-white hover:bg-white/10 gap-1 px-2 py-1 h-8"
            >
              <LogOut className="w-3.5 h-3.5" />
              <span className="hidden md:inline text-xs">خروج</span>
            </Button>
          </div>
        </div>
      </div>
    </header>
  );
}
