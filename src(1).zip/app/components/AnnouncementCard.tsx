import { Announcement } from '../App';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Calendar, User, Building2, AlertCircle } from 'lucide-react';
import { Button } from './ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from './ui/dialog';

interface AnnouncementCardProps {
  announcement: Announcement;
}

const categoryLabels = {
  academic: { label: 'أكاديمي', color: 'bg-emerald-100 text-emerald-800' },
  events: { label: 'فعاليات', color: 'bg-teal-100 text-teal-800' },
  jobs: { label: 'وظائف', color: 'bg-green-100 text-green-800' },
  sports: { label: 'رياضة', color: 'bg-lime-100 text-lime-800' },
  general: { label: 'عام', color: 'bg-gray-100 text-gray-800' }
};

const priorityLabels = {
  high: { label: 'عاجل', color: 'bg-red-100 text-red-800' },
  medium: { label: 'متوسط', color: 'bg-yellow-100 text-yellow-800' },
  low: { label: 'عادي', color: 'bg-gray-100 text-gray-800' }
};

export function AnnouncementCard({ announcement }: AnnouncementCardProps) {
  const categoryInfo = categoryLabels[announcement.category];
  const priorityInfo = priorityLabels[announcement.priority];
  
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('ar-EG', { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };

  return (
    <Card className="hover:shadow-lg transition-all duration-300 hover:-translate-y-1" style={{ borderColor: '#d4e7dc' }}>
      <CardHeader>
        <div className="flex justify-between items-start mb-2">
          <Badge className={categoryInfo.color}>
            {categoryInfo.label}
          </Badge>
          {announcement.priority === 'high' && (
            <Badge className={priorityInfo.color}>
              <AlertCircle className="w-3 h-3 ml-1" />
              {priorityInfo.label}
            </Badge>
          )}
        </div>
        <CardTitle className="text-gray-900 leading-tight">
          {announcement.title}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <p className="text-gray-600 mb-4 line-clamp-3">
          {announcement.description}
        </p>
        
        <div className="space-y-2 text-sm text-gray-500 mb-4">
          <div className="flex items-center gap-2">
            <User className="w-4 h-4" />
            <span>{announcement.author}</span>
          </div>
          {announcement.department && (
            <div className="flex items-center gap-2">
              <Building2 className="w-4 h-4" />
              <span>{announcement.department}</span>
            </div>
          )}
          <div className="flex items-center gap-2">
            <Calendar className="w-4 h-4" />
            <span>{formatDate(announcement.date)}</span>
          </div>
        </div>

        <Dialog>
          <DialogTrigger asChild>
            <Button variant="outline" className="w-full" style={{ borderColor: '#d4e7dc', color: '#427E5A' }}>
              عرض التفاصيل
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl" dir="rtl">
            <DialogHeader>
              <div className="flex gap-2 mb-3">
                <Badge className={categoryInfo.color}>
                  {categoryInfo.label}
                </Badge>
                {announcement.priority === 'high' && (
                  <Badge className={priorityInfo.color}>
                    <AlertCircle className="w-3 h-3 ml-1" />
                    {priorityInfo.label}
                  </Badge>
                )}
              </div>
              <DialogTitle className="text-right text-gray-900">
                {announcement.title}
              </DialogTitle>
              <DialogDescription className="text-right text-gray-600">
                {announcement.description}
              </DialogDescription>
            </DialogHeader>
            <div className="space-y-3 mt-4">
              <div className="flex items-center gap-2 text-gray-700">
                <User className="w-5 h-5 text-gray-500" />
                <span>الناشر: {announcement.author}</span>
              </div>
              {announcement.department && (
                <div className="flex items-center gap-2 text-gray-700">
                  <Building2 className="w-5 h-5 text-gray-500" />
                  <span>القسم: {announcement.department}</span>
                </div>
              )}
              <div className="flex items-center gap-2 text-gray-700">
                <Calendar className="w-5 h-5 text-gray-500" />
                <span>تاريخ النشر: {formatDate(announcement.date)}</span>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  );
}
