import { useState } from 'react';
import { BookOpen, Calendar, Clock, MapPin, User, DollarSign, Wifi, Link as LinkIcon } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Course } from '../App';

interface CoursesSectionProps {
  searchQuery: string;
  selectedCollege: string;
}

const mockCourses: Course[] = [
  {
    id: '1',
    title: 'الذكاء الاصطناعي وتطبيقاته',
    description: 'دورة شاملة تغطي أساسيات الذكاء الاصطناعي وتطبيقاته في مختلف المجالات',
    college: 'cs',
    isFree: true,
    isOnline: false,
    instructor: 'د. أحمد الغامدي',
    date: '2025-11-05',
    time: '10:00 ص - 12:00 م',
    location: 'قاعة 201 - مبنى علوم الحاسب',
    registrationLink: '#'
  },
  {
    id: '2',
    title: 'برمجة تطبيقات الويب الحديثة',
    description: 'تعلم React و TypeScript لبناء تطبيقات ويب احترافية',
    college: 'cs',
    isFree: false,
    isOnline: true,
    instructor: 'أ. سارة القحطاني',
    date: '2025-11-08',
    time: '4:00 م - 6:00 م',
    location: 'عن بعد - Zoom',
    registrationLink: '#'
  },
  {
    id: '3',
    title: 'أساسيات الطب السريري',
    description: 'مقدمة في الممارسات الطبية السريرية للطلاب الجدد',
    college: 'medicine',
    isFree: true,
    isOnline: false,
    instructor: 'د. فاطمة العمري',
    date: '2025-11-10',
    time: '9:00 ص - 11:00 ص',
    location: 'قاعة المحاضرات الرئيسية - كلية الطب',
    registrationLink: '#'
  },
  {
    id: '4',
    title: 'تصميم الدوائر الإلكترونية',
    description: 'تعلم أساسيات تصميم وتحليل الدوائر الإلكترونية',
    college: 'engineering',
    isFree: true,
    isOnline: false,
    instructor: 'م. خالد الشهري',
    date: '2025-11-12',
    time: '2:00 م - 4:00 م',
    location: 'مختبر الهندسة الكهربائية',
    registrationLink: '#'
  }
];

export function CoursesSection({ searchQuery, selectedCollege }: CoursesSectionProps) {
  const filteredCourses = mockCourses.filter(course => {
    const matchesCollege = selectedCollege === 'all' || course.college === selectedCollege;
    const matchesSearch = course.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         course.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCollege && matchesSearch;
  });

  return (
    <div>
      <div className="flex items-center gap-3 mb-6">
        <div className="p-3 rounded-lg" style={{ background: 'linear-gradient(to right, #427E5A, #5a9b72)' }}>
          <BookOpen className="w-6 h-6 text-white" />
        </div>
        <div>
          <h2 className="text-gray-900">الدورات القادمة</h2>
          <p className="text-gray-600 text-sm">اكتشف الدورات التدريبية التي تقدمها الجامعة</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredCourses.map((course) => (
          <CourseCard key={course.id} course={course} />
        ))}
      </div>

      {filteredCourses.length === 0 && (
        <div className="text-center py-12 bg-white/50 rounded-xl">
          <BookOpen className="w-16 h-16 mx-auto mb-4" style={{ color: '#d4e7dc' }} />
          <p className="text-gray-600">لا توجد دورات متاحة حالياً</p>
        </div>
      )}
    </div>
  );
}

function CourseCard({ course }: { course: Course }) {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('ar-SA', { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };

  return (
    <Card className="hover:shadow-xl transition-all duration-300 hover:-translate-y-1 bg-white/90 backdrop-blur-sm" style={{ borderColor: '#d4e7dc' }}>
      <CardHeader>
        <div className="flex gap-2 mb-2">
          <Badge className={course.isFree ? '' : 'bg-amber-100 text-amber-800'} style={course.isFree ? { backgroundColor: '#d4e7dc', color: '#2d5a3f' } : {}}>
            {course.isFree ? 'مجانية' : 'مدفوعة'}
          </Badge>
          <Badge className={course.isOnline ? 'bg-blue-100 text-blue-800' : 'bg-purple-100 text-purple-800'}>
            {course.isOnline ? 'عن بعد' : 'حضورية'}
          </Badge>
        </div>
        <CardTitle className="text-gray-900 leading-tight">
          {course.title}
        </CardTitle>
        <CardDescription className="text-gray-600">
          {course.description}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-2 mb-4">
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <User className="w-4 h-4" style={{ color: '#427E5A' }} />
            <span>{course.instructor}</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <Calendar className="w-4 h-4" style={{ color: '#427E5A' }} />
            <span>{formatDate(course.date)}</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <Clock className="w-4 h-4" style={{ color: '#427E5A' }} />
            <span>{course.time}</span>
          </div>
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <MapPin className="w-4 h-4" style={{ color: '#427E5A' }} />
            <span>{course.location}</span>
          </div>
        </div>

        <Button 
          className="w-full gap-2 text-white hover:opacity-90"
          style={{ background: 'linear-gradient(to right, #427E5A, #5a9b72)' }}
          onClick={() => window.open(course.registrationLink, '_blank')}
        >
          <LinkIcon className="w-4 h-4" />
          حجز مقعد
        </Button>
      </CardContent>
    </Card>
  );
}
