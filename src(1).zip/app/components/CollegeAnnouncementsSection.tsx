import { CoursesSection } from './CoursesSection';
import { ClubsSection } from './ClubsSection';

interface CollegeAnnouncementsSectionProps {
  searchQuery: string;
  selectedCollege: string;
}

export function CollegeAnnouncementsSection({ searchQuery, selectedCollege }: CollegeAnnouncementsSectionProps) {
  return (
    <div className="space-y-8">
      <CoursesSection searchQuery={searchQuery} selectedCollege={selectedCollege} />
      <ClubsSection searchQuery={searchQuery} selectedCollege={selectedCollege} />
    </div>
  );
}
