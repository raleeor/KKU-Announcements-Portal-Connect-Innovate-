import { Search, Filter, Monitor, Stethoscope, Cog, Briefcase, Microscope, BookOpen } from 'lucide-react';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';

interface SearchBarProps {
  searchQuery: string;
  onSearchChange: (query: string) => void;
  selectedCollege: string;
  onCollegeChange: (college: string) => void;
}

const colleges = [
  { id: 'all', name: 'جميع الكليات', icon: null },
  { id: 'cs', name: 'كلية علوم الحاسب', icon: Monitor },
  { id: 'medicine', name: 'كلية الطب', icon: Stethoscope },
  { id: 'engineering', name: 'كلية الهندسة', icon: Cog },
  { id: 'business', name: 'كلية إدارة الأعمال', icon: Briefcase },
  { id: 'science', name: 'كلية العلوم', icon: Microscope },
  { id: 'arts', name: 'كلية الآداب', icon: BookOpen },
];

export function SearchBar({ searchQuery, onSearchChange, selectedCollege, onCollegeChange }: SearchBarProps) {
  return (
    <div className="bg-white/80 backdrop-blur-sm rounded-2xl shadow-lg p-6" style={{ borderColor: '#d4e7dc', borderWidth: '1px' }}>
      <div className="flex items-center gap-2 mb-4">
        <Search className="w-5 h-5" style={{ color: '#427E5A' }} />
        <h3 className="text-gray-900">البحث والتصفية</h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="relative">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5" style={{ color: '#5a9b72' }} />
          <Input
            type="text"
            placeholder="ابحث في الإعلانات..."
            value={searchQuery}
            onChange={(e) => onSearchChange(e.target.value)}
            className="pr-10"
            style={{ borderColor: '#d4e7dc' }}
          />
        </div>

        <div className="relative">
          <Filter className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 pointer-events-none z-10" style={{ color: '#5a9b72' }} />
          <Select value={selectedCollege} onValueChange={onCollegeChange}>
            <SelectTrigger className="pr-10" style={{ borderColor: '#d4e7dc' }}>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {colleges.map((college) => {
                const Icon = college.icon;
                return (
                  <SelectItem key={college.id} value={college.id}>
                    <div className="flex items-center gap-2">
                      {Icon && <Icon className="w-4 h-4" style={{ color: '#427E5A' }} />}
                      <span>{college.name}</span>
                    </div>
                  </SelectItem>
                );
              })}
            </SelectContent>
          </Select>
        </div>
      </div>
    </div>
  );
}
