import { History, Calendar, User, CheckCircle } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';

interface CompletedCourse {
  id: string;
  title: string;
  instructor: string;
  completionDate: string;
  college: string;
  certificateUrl?: string;
}

const mockCompletedCourses: CompletedCourse[] = [
  {
    id: '1',
    title: 'أساسيات البرمجة بلغة Python',
    instructor: 'د. أحمد الغامدي',
    completionDate: '2025-09-15',
    college: 'كلية علوم الحاسب',
    certificateUrl: '#'
  },
  {
    id: '2',
    title: 'تطوير تطبيقات الويب',
    instructor: 'أ. سارة القحطاني',
    completionDate: '2025-08-20',
    college: 'كلية علوم الحاسب',
    certificateUrl: '#'
  },
  {
    id: '3',
    title: 'مهارات التواصل الفعال',
    instructor: 'د. محمد العمري',
    completionDate: '2025-07-10',
    college: 'كلية الآداب'
  }
];

export function CoursesHistoryPage() {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('ar-SA', { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };

  return (
    <main className="container mx-auto px-4 py-6 max-w-4xl">
      <div className="flex items-center gap-3 mb-8">
        <div className="p-3 rounded-lg" style={{ background: 'linear-gradient(to right, #427E5A, #5a9b72)' }}>
          <History className="w-6 h-6 text-white" />
        </div>
        <div>
          <h1 className="text-gray-900">سجل الدورات</h1>
          <p className="text-gray-600 text-sm">الدورات التي تم حضورها وإكمالها</p>
        </div>
      </div>

      {mockCompletedCourses.length === 0 ? (
        <div className="text-center py-16 bg-white/50 rounded-xl">
          <History className="w-16 h-16 mx-auto mb-4" style={{ color: '#d4e7dc' }} />
          <p className="text-gray-600">لم تحضر أي دورات بعد</p>
        </div>
      ) : (
        <div className="space-y-4">
          <div className="flex items-center justify-between mb-4">
            <p className="text-gray-600">
              إجمالي الدورات المكتملة: <span className="font-bold" style={{ color: '#427E5A' }}>{mockCompletedCourses.length}</span>
            </p>
          </div>

          {mockCompletedCourses.map((course) => (
            <Card key={course.id} className="bg-white/90 backdrop-blur-sm" style={{ borderColor: '#d4e7dc' }}>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <CheckCircle className="w-5 h-5" style={{ color: '#427E5A' }} />
                      <Badge className="text-xs" style={{ backgroundColor: '#d4e7dc', color: '#2d5a3f' }}>
                        مكتملة
                      </Badge>
                    </div>
                    <CardTitle className="text-gray-900">{course.title}</CardTitle>
                    <CardDescription className="text-gray-600 mt-1">
                      {course.college}
                    </CardDescription>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <User className="w-4 h-4" style={{ color: '#427E5A' }} />
                    <span>المحاضر: {course.instructor}</span>
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Calendar className="w-4 h-4" style={{ color: '#427E5A' }} />
                    <span>تاريخ الإكمال: {formatDate(course.completionDate)}</span>
                  </div>
                  {course.certificateUrl && (
                    <div className="mt-4">
                      <a 
                        href={course.certificateUrl}
                        className="text-sm hover:underline inline-flex items-center gap-1"
                        style={{ color: '#427E5A' }}
                      >
                        📜 تحميل الشهادة
                      </a>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </main>
  );
}
