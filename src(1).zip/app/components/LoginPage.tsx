import { useState } from 'react';
import { GraduationCap, Lock, User, LogIn } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { toast } from 'sonner@2.0.3';

interface LoginPageProps {
  onLogin: (universityId: string, password: string) => void;
}

export function LoginPage({ onLogin }: LoginPageProps) {
  const [universityId, setUniversityId] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!universityId || !password) {
      toast.error('يرجى إدخال الرقم الجامعي وكلمة المرور');
      return;
    }

    setIsLoading(true);
    
    // محاكاة عملية تسجيل الدخول
    setTimeout(() => {
      if (password === 'password' || password === '123456' || password === 'manager') {
        if (password === 'manager') {
          toast.success('مرحباً! تم تسجيل الدخول كمسؤول');
        } else {
          toast.success('تم تسجيل الدخول بنجاح');
        }
        onLogin(universityId, password);
      } else {
        toast.error('الرقم الجامعي أو كلمة المرور غير صحيحة');
        setIsLoading(false);
      }
    }, 1000);
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4" style={{ background: 'linear-gradient(to bottom right, #f0f7f3, #e8f4ed, #f5faf7)' }} dir="rtl">
      <div className="w-full max-w-6xl grid md:grid-cols-2 gap-8 items-center">
        {/* Right Side - Branding */}
        <div className="hidden md:flex flex-col items-center justify-center text-center space-y-6">
          <div className="p-8 rounded-3xl shadow-2xl" style={{ background: 'linear-gradient(to bottom right, #427E5A, #5a9b72)' }}>
            <GraduationCap className="w-32 h-32 text-white" />
          </div>
          <div>
            <h1 className="mb-3" style={{ color: '#2d5a3f' }}>
              جامعة الملك خالد
            </h1>
            <h2 className="mb-4" style={{ color: '#427E5A' }}>
              King Khalid University
            </h2>
            <p className="text-lg max-w-md mx-auto" style={{ color: '#5a9b72' }}>
              نظام الإعلانات الإلكترونية
            </p>
            <p className="mt-2" style={{ color: '#427E5A' }}>
              تابع آخر الأخبار والإعلانات الجامعية
            </p>
          </div>
        </div>

        {/* Left Side - Login Form */}
        <Card className="shadow-2xl" style={{ borderColor: '#d4e7dc' }}>
          <CardHeader className="space-y-1 text-center md:text-right">
            <div className="flex items-center justify-center md:hidden mb-4">
              <div className="p-4 rounded-2xl" style={{ background: 'linear-gradient(to bottom right, #427E5A, #5a9b72)' }}>
                <GraduationCap className="w-16 h-16 text-white" />
              </div>
            </div>
            <CardTitle style={{ color: '#2d5a3f' }}>
              تسجيل الدخول
            </CardTitle>
            <CardDescription>
              أدخل الرقم الجامعي وكلمة المرور للوصول إلى النظام
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="universityId" style={{ color: '#2d5a3f' }}>
                  الرقم الجامعي
                </Label>
                <div className="relative">
                  <User className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5" style={{ color: '#427E5A' }} />
                  <Input
                    id="universityId"
                    type="text"
                    placeholder="مثال: 443123456"
                    value={universityId}
                    onChange={(e) => setUniversityId(e.target.value)}
                    className="pr-10"
                    style={{ borderColor: '#d4e7dc' }}
                    required
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" style={{ color: '#2d5a3f' }}>
                  كلمة المرور
                </Label>
                <div className="relative">
                  <Lock className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5" style={{ color: '#427E5A' }} />
                  <Input
                    id="password"
                    type="password"
                    placeholder="أدخل كلمة المرور"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="pr-10"
                    style={{ borderColor: '#d4e7dc' }}
                    required
                  />
                </div>
              </div>

              <div className="flex items-center justify-between text-sm">
                <a href="#" className="hover:underline" style={{ color: '#427E5A' }}>
                  نسيت كلمة المرور؟
                </a>
              </div>

              <Button
                type="submit"
                className="w-full text-white"
                style={{ background: 'linear-gradient(to right, #427E5A, #5a9b72)' }}
                disabled={isLoading}
              >
                {isLoading ? (
                  <span className="flex items-center gap-2">
                    <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    جاري تسجيل الدخول...
                  </span>
                ) : (
                  <span className="flex items-center gap-2">
                    <LogIn className="w-5 h-5" />
                    تسجيل الدخول
                  </span>
                )}
              </Button>

              <div className="pt-4 border-t" style={{ borderColor: '#d4e7dc' }}>
                <p className="text-sm text-center" style={{ color: '#5a9b72' }}>
                  للتجربة: استخدم أي رقم جامعي<br/>
                  كلمة المرور: <span className="font-mono px-2 py-1 rounded" style={{ backgroundColor: '#f0f7f3' }}>password</span> أو <span className="font-mono px-2 py-1 rounded" style={{ backgroundColor: '#f0f7f3' }}>manager</span> (للمسؤولين)
                </p>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>

      {/* Decorative Elements */}
      <div className="fixed top-10 right-10 w-32 h-32 rounded-full blur-3xl opacity-50 pointer-events-none" style={{ backgroundColor: '#d4e7dc' }} />
      <div className="fixed bottom-10 left-10 w-40 h-40 rounded-full blur-3xl opacity-50 pointer-events-none" style={{ backgroundColor: '#c4ddd0' }} />
    </div>
  );
}
