import { Search, Filter } from 'lucide-react';
import { Input } from './ui/input';
import { Button } from './ui/button';
import { Badge } from './ui/badge';

interface FilterBarProps {
  selectedCategory: string;
  onCategoryChange: (category: string) => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
}

const categories = [
  { id: 'all', label: 'الكل', color: 'bg-gray-100 text-gray-800 hover:bg-gray-200' },
  { id: 'academic', label: 'أكاديمي', color: 'bg-emerald-100 text-emerald-800 hover:bg-emerald-200' },
  { id: 'events', label: 'فعاليات', color: 'bg-teal-100 text-teal-800 hover:bg-teal-200' },
  { id: 'jobs', label: 'وظائف', color: 'bg-green-100 text-green-800 hover:bg-green-200' },
  { id: 'sports', label: 'رياضة', color: 'bg-lime-100 text-lime-800 hover:bg-lime-200' },
  { id: 'general', label: 'عام', color: 'bg-gray-100 text-gray-800 hover:bg-gray-200' }
];

export function FilterBar({ selectedCategory, onCategoryChange, searchQuery, onSearchChange }: FilterBarProps) {
  return (
    <div className="bg-white rounded-xl shadow-sm p-6 mb-6" style={{ borderColor: '#d4e7dc', borderWidth: '1px' }}>
      <div className="flex items-center gap-2 mb-4">
        <Filter className="w-5 h-5" style={{ color: '#427E5A' }} />
        <h3 className="text-gray-900">تصفية وبحث</h3>
      </div>

      <div className="relative mb-4">
        <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5" style={{ color: '#5a9b72' }} />
        <Input
          type="text"
          placeholder="ابحث في الإعلانات..."
          value={searchQuery}
          onChange={(e) => onSearchChange(e.target.value)}
          className="pr-10"
          style={{ borderColor: '#d4e7dc' }}
        />
      </div>

      <div className="flex flex-wrap gap-2">
        {categories.map((category) => (
          <Button
            key={category.id}
            onClick={() => onCategoryChange(category.id)}
            variant={selectedCategory === category.id ? 'default' : 'outline'}
            size="sm"
            className={selectedCategory === category.id ? '' : category.color}
          >
            {category.label}
          </Button>
        ))}
      </div>
    </div>
  );
}
