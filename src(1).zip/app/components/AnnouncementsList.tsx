import { Announcement } from '../App';
import { AnnouncementCard } from './AnnouncementCard';
import { FileQuestion } from 'lucide-react';

interface AnnouncementsListProps {
  announcements: Announcement[];
}

export function AnnouncementsList({ announcements }: AnnouncementsListProps) {
  if (announcements.length === 0) {
    return (
      <div className="text-center py-16 bg-white rounded-xl shadow-sm" style={{ borderColor: '#d4e7dc', borderWidth: '1px' }}>
        <FileQuestion className="w-16 h-16 mx-auto mb-4" style={{ color: '#d4e7dc' }} />
        <h3 className="text-gray-900 mb-2">لا توجد إعلانات</h3>
        <p className="text-gray-600">
          لم يتم العثور على إعلانات تطابق معايير البحث
        </p>
      </div>
    );
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {announcements.map((announcement) => (
        <AnnouncementCard key={announcement.id} announcement={announcement} />
      ))}
    </div>
  );
}
