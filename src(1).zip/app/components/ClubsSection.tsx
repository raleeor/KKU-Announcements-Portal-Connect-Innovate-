import { Users, Calendar, Code, Dumbbell, Stethoscope, Camera } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { ClubAnnouncement } from '../App';

interface ClubsSectionProps {
  searchQuery: string;
  selectedCollege: string;
}

const mockClubAnnouncements: ClubAnnouncement[] = [
  {
    id: '1',
    title: 'مسابقة البرمجة السنوية',
    description: 'نادي البرمجة يدعوكم للمشاركة في المسابقة السنوية للبرمجة. جوائز قيمة للفائزين!',
    club: 'نادي البرمجة',
    college: 'cs',
    date: '2025-11-15'
  },
  {
    id: '2',
    title: 'ورشة عمل التصوير الفوتوغرافي',
    description: 'انضم إلينا في ورشة تعليمية عن أساسيات التصوير الاحترافي',
    club: 'نادي التصوير',
    college: 'arts',
    date: '2025-11-12'
  },
  {
    id: '3',
    title: 'بطولة كرة القدم بين الأقسام',
    description: 'النادي الرياضي ينظم بطولة كرة قدم. سجل فريقك الآن!',
    club: 'النادي الرياضي',
    college: 'all',
    date: '2025-11-20'
  },
  {
    id: '4',
    title: 'معرض الابتكار الطبي',
    description: 'نادي الطب يقدم معرضاً للابتكارات الطبية الحديثة',
    club: 'النادي الطبي',
    college: 'medicine',
    date: '2025-11-18'
  }
];

export function ClubsSection({ searchQuery, selectedCollege }: ClubsSectionProps) {
  const filteredAnnouncements = mockClubAnnouncements.filter(announcement => {
    const matchesCollege = selectedCollege === 'all' || announcement.college === selectedCollege || announcement.college === 'all';
    const matchesSearch = announcement.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         announcement.description.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCollege && matchesSearch;
  });

  return (
    <div>
      <div className="flex items-center gap-3 mb-6">
        <div className="p-3 rounded-lg" style={{ background: 'linear-gradient(to right, #427E5A, #5a9b72)' }}>
          <Users className="w-6 h-6 text-white" />
        </div>
        <div>
          <h2 className="text-gray-900">إعلانات النوادي</h2>
          <p className="text-gray-600 text-sm">آخر أخبار وفعاليات النوادي الطلابية</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {filteredAnnouncements.map((announcement) => (
          <ClubAnnouncementCard key={announcement.id} announcement={announcement} />
        ))}
      </div>

      {filteredAnnouncements.length === 0 && (
        <div className="text-center py-12 bg-white/50 rounded-xl">
          <Users className="w-16 h-16 mx-auto mb-4" style={{ color: '#d4e7dc' }} />
          <p className="text-gray-600">لا توجد إعلانات من النوادي حالياً</p>
        </div>
      )}
    </div>
  );
}

function ClubAnnouncementCard({ announcement }: { announcement: ClubAnnouncement }) {
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('ar-SA', { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
  };

  const getClubIcon = (clubName: string) => {
    if (clubName.includes('البرمجة')) {
      return <Code className="w-5 h-5" style={{ color: '#427E5A' }} />;
    } else if (clubName.includes('الرياضي')) {
      return <Dumbbell className="w-5 h-5" style={{ color: '#427E5A' }} />;
    } else if (clubName.includes('الطب')) {
      return <Stethoscope className="w-5 h-5" style={{ color: '#427E5A' }} />;
    } else if (clubName.includes('التصوير')) {
      return <Camera className="w-5 h-5" style={{ color: '#427E5A' }} />;
    }
    return <Users className="w-5 h-5" style={{ color: '#427E5A' }} />;
  };

  return (
    <Card className="hover:shadow-xl transition-all duration-300 hover:-translate-y-1 bg-white/90 backdrop-blur-sm" style={{ borderColor: '#c4ddd0' }}>
      <CardHeader>
        <div className="flex items-center gap-2 mb-2">
          <div className="p-2 rounded-lg" style={{ backgroundColor: '#f0f7f3' }}>
            {getClubIcon(announcement.club)}
          </div>
          <Badge style={{ backgroundColor: '#d4e7dc', color: '#2d5a3f' }}>
            {announcement.club}
          </Badge>
        </div>
        <CardTitle className="text-gray-900 leading-tight mt-2">
          {announcement.title}
        </CardTitle>
        <CardDescription className="text-gray-600">
          {announcement.description}
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-2">
          <div className="flex items-center gap-2 text-sm text-gray-600">
            <Calendar className="w-4 h-4" style={{ color: '#427E5A' }} />
            <span>{formatDate(announcement.date)}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
