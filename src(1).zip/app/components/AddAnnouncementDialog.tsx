import { useState } from 'react';
import { Plus } from 'lucide-react';
import { Button } from './ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from './ui/dialog';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import { Announcement } from '../App';
import { toast } from 'sonner@2.0.3';

interface AddAnnouncementDialogProps {
  onAdd: (announcement: Omit<Announcement, 'id' | 'date'>) => void;
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
}

export function AddAnnouncementDialog({ onAdd, open: controlledOpen, onOpenChange }: AddAnnouncementDialogProps) {
  const [internalOpen, setInternalOpen] = useState(false);
  const open = controlledOpen !== undefined ? controlledOpen : internalOpen;
  const setOpen = onOpenChange || setInternalOpen;
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    category: 'general' as Announcement['category'],
    author: '',
    priority: 'medium' as Announcement['priority'],
    department: ''
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!formData.title || !formData.description || !formData.author) {
      toast.error('يرجى ملء جميع الحقول المطلوبة');
      return;
    }

    onAdd(formData);
    toast.success('تم إضافة الإعلان بنجاح');
    
    // Reset form
    setFormData({
      title: '',
      description: '',
      category: 'general',
      author: '',
      priority: 'medium',
      department: ''
    });
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button className="gap-2 text-white hover:opacity-90" style={{ background: 'linear-gradient(to right, #427E5A, #5a9b72)' }}>
          <Plus className="w-5 h-5" />
          إضافة إعلان جديد
        </Button>
      </DialogTrigger>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto" dir="rtl">
        <DialogHeader>
          <DialogTitle className="text-right text-gray-900">
            إضافة إعلان جديد
          </DialogTitle>
          <DialogDescription className="text-right text-gray-600">
            قم بملء البيانات أدناه لإضافة إعلان جديد
          </DialogDescription>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="space-y-4 mt-4">
          <div className="space-y-2">
            <Label htmlFor="title">عنوان الإعلان *</Label>
            <Input
              id="title"
              value={formData.title}
              onChange={(e) => setFormData({ ...formData, title: e.target.value })}
              placeholder="أدخل عنوان الإعلان"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description">وصف الإعلان *</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="أدخل تفاصيل الإعلان"
              rows={4}
              required
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="category">الفئة *</Label>
              <Select
                value={formData.category}
                onValueChange={(value) => setFormData({ ...formData, category: value as Announcement['category'] })}
              >
                <SelectTrigger id="category">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="academic">أكاديمي</SelectItem>
                  <SelectItem value="events">فعاليات</SelectItem>
                  <SelectItem value="jobs">وظائف</SelectItem>
                  <SelectItem value="sports">رياضة</SelectItem>
                  <SelectItem value="general">عام</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="priority">الأولوية *</Label>
              <Select
                value={formData.priority}
                onValueChange={(value) => setFormData({ ...formData, priority: value as Announcement['priority'] })}
              >
                <SelectTrigger id="priority">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="high">عاجل</SelectItem>
                  <SelectItem value="medium">متوسط</SelectItem>
                  <SelectItem value="low">عادي</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="author">الناشر *</Label>
            <Input
              id="author"
              value={formData.author}
              onChange={(e) => setFormData({ ...formData, author: e.target.value })}
              placeholder="اسم الجهة أو الشخص الناشر"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="department">القسم (اختياري)</Label>
            <Input
              id="department"
              value={formData.department}
              onChange={(e) => setFormData({ ...formData, department: e.target.value })}
              placeholder="القسم أو الكلية"
            />
          </div>

          <div className="flex gap-3 justify-end pt-4">
            <Button type="button" variant="outline" onClick={() => setOpen(false)}>
              إلغاء
            </Button>
            <Button type="submit">
              إضافة الإعلان
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}
