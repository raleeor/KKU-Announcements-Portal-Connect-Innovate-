import { useState } from 'react';
import { Header } from './Header';
import { HomePage } from './HomePage';
import { SettingsPage } from './SettingsPage';
import { CoursesHistoryPage } from './CoursesHistoryPage';
import { SuggestionsPage } from './SuggestionsPage';
import { AddAnnouncementDialog } from './AddAnnouncementDialog';
import { Settings } from '../App';

interface MainLayoutProps {
  currentUser: string;
  onLogout: () => void;
  settings: Settings;
  onSettingsChange: (settings: Settings) => void;
  isManager: boolean;
}

export function MainLayout({ currentUser, onLogout, settings, onSettingsChange, isManager }: MainLayoutProps) {
  const [currentPage, setCurrentPage] = useState<'home' | 'settings' | 'history' | 'suggestions'>('home');
  const [showAddDialog, setShowAddDialog] = useState(false);

  const handleAddAnnouncement = (announcement: any) => {
    // This would add the announcement to the state
    console.log('New announcement:', announcement);
    setShowAddDialog(false);
  };

  return (
    <div className={`min-h-screen ${settings.theme === 'dark' ? 'dark bg-gray-900' : ''}`} style={settings.theme === 'light' ? { background: 'linear-gradient(to bottom right, #f0f7f3, #e8f4ed, #f5faf7)' } : {}} dir="rtl">
      <Header 
        currentUser={currentUser} 
        onLogout={onLogout}
        currentPage={currentPage}
        onPageChange={setCurrentPage}
        isManager={isManager}
        onAddAnnouncement={isManager ? () => setShowAddDialog(true) : undefined}
      />
      
      {currentPage === 'home' && <HomePage settings={settings} />}
      {currentPage === 'settings' && (
        <SettingsPage 
          settings={settings} 
          onSettingsChange={onSettingsChange}
          onNavigate={setCurrentPage}
        />
      )}
      {currentPage === 'history' && <CoursesHistoryPage />}
      {currentPage === 'suggestions' && <SuggestionsPage />}

      {isManager && (
        <AddAnnouncementDialog 
          open={showAddDialog}
          onOpenChange={setShowAddDialog}
          onAdd={handleAddAnnouncement}
        />
      )}
    </div>
  );
}
