import { useState } from 'react';
import { SearchBar } from './SearchBar';
import { CollegeAnnouncementsSection } from './CollegeAnnouncementsSection';
import { GeneralAnnouncementsSection } from './GeneralAnnouncementsSection';
import { Settings } from '../App';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';

interface HomePageProps {
  settings: Settings;
}

export function HomePage({ settings }: HomePageProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCollege, setSelectedCollege] = useState<string>('all');

  return (
    <main className="container mx-auto px-4 py-6 max-w-7xl">
      {/* Search and Filter Section */}
      <div className="mb-8">
        <SearchBar 
          searchQuery={searchQuery}
          onSearchChange={setSearchQuery}
          selectedCollege={selectedCollege}
          onCollegeChange={setSelectedCollege}
        />
      </div>

      {/* Main Sections */}
      <Tabs defaultValue="college" className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-6 bg-white/80 backdrop-blur-sm">
          <TabsTrigger 
            value="college" 
            className="data-[state=active]:text-white"
            style={{ 
              background: 'var(--tab-bg, transparent)',
              '--tab-bg': 'transparent'
            } as any}
            onMouseEnter={(e) => e.currentTarget.classList.contains('data-[state=active]') && (e.currentTarget.style.setProperty('--tab-bg', 'linear-gradient(to right, #427E5A, #5a9b72)'))}
            data-active-class="kku-green-gradient"
          >
            إعلانات الكليات
          </TabsTrigger>
          <TabsTrigger 
            value="general" 
            className="data-[state=active]:text-white"
            data-active-class="kku-green-gradient"
          >
            الإعلانات العامة
          </TabsTrigger>
        </TabsList>
        
        <TabsContent value="college" className="space-y-6">
          <CollegeAnnouncementsSection 
            searchQuery={searchQuery}
            selectedCollege={selectedCollege}
          />
        </TabsContent>
        
        <TabsContent value="general" className="space-y-6">
          <GeneralAnnouncementsSection searchQuery={searchQuery} />
        </TabsContent>
      </Tabs>

      <style>{`
        [data-state="active"][data-active-class="kku-green-gradient"] {
          background: linear-gradient(to right, #427E5A, #5a9b72) !important;
        }
      `}</style>
    </main>
  );
}
